Jack's Board Optimizer — Android project

This Android Studio project wraps the standalone board cutting optimiser in an Android WebView.

To build an APK:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK platform/build tools.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

The project uses Android Gradle Plugin 8.7.3 and compile SDK 35.
